package com.sew.accessibility_application.activities

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Patterns
import com.sew.accessibility_application.R
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        tvRegisterNow.setOnClickListener {
            val intent = Intent(this@LoginActivity, RegistrationActivity::class.java)
            startActivity(intent)
            finish()
        }

//        tieEmailInput.addTextChangedListener(object : TextWatcher {
//            override fun afterTextChanged(s: Editable?) {
//            }
//
//            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
//            }
//
//            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
//                if (!Patterns.EMAIL_ADDRESS.matcher(tieEmailInput.text.toString().trim())
//                        .matches()
//                ) {
//                    tieEmailInput.error = EMAIL_ERROR
//                } else {
//                    tieEmailInput.error = null
//                }
//            }
//        })

        btnLogin.setOnClickListener {
            when {
                tieEmailInput.text.toString().trim().isEmpty() || (!Patterns.EMAIL_ADDRESS.matcher(
                    tieEmailInput.text.toString().trim()
                ).matches()) -> {
                    it.announceForAccessibility(EMAIL_ERROR)
                }
                tiePasswordInput.text.toString().trim().isEmpty() -> {
                    it.announceForAccessibility(PASSWORD_ERROR)
                }
                else -> {
                    val intent = Intent(this@LoginActivity, HomeActivity::class.java)
                    startActivity(intent)
                    finish()
                }
            }
        }

    }

}
